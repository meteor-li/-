# default_app_config = app中文名称设置类的路径，从app开始到类
default_app_config = 'blog.apps.BlogConfig'