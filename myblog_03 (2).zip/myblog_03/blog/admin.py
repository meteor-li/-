from django.contrib import admin
# import xadmin
# Register your models here.
# from .models import Post, Category, Tag,User
#
# class UserAdmin(object):
# 	list_display =  ['id','name' ]# 设置数据表在后台显示的字段
# 	search_fields = ['id','name' ] # 设置在后台可以搜素的字段
# 	list_filter =   ['id','name' ] # 设置在后台可以通过条件帅选查看的字段
# xadmin.site.register(User, UserAdmin) # 将制定表注册到xadmin后台
#
# class PostAdmin(object):
# 	list_display =  ['id','title', 'created_time', 'modified_time', 'category', ]# 设置数据表在后台显示的字段
# 	search_fields = ['id','title', 'created_time', 'modified_time', 'category', ] # 设置在后台可以搜素的字段
# 	list_filter =   ['id','title', 'created_time', 'modified_time', 'category', ] # 设置在后台可以通过条件帅选查看的字段
# xadmin.site.register(Post, PostAdmin) # 将制定表注册到xadmin后台
#
# class CategoryAdmin(object):
# 	list_display =  ['id', 'name']# 设置数据表在后台显示的字段
# 	search_fields = ['id', 'name'] # 设置在后台可以搜素的字段
# 	list_filter =   ['id', 'name'] # 设置在后台可以通过条件帅选查看的字段
# xadmin.site.register(Category, CategoryAdmin) # 将制定表注册到xadmin后台
#
# class TagAdmin(object):
# 	list_display =  ['id', 'name']# 设置数据表在后台显示的字段
# 	search_fields = ['id', 'name'] # 设置在后台可以搜素的字段
# 	list_filter =   ['id', 'name'] # 设置在后台可以通过条件帅选查看的字段
# xadmin.site.register(Tag, TagAdmin) # 将制定表注册到xadmin后台

# class PostAdmin(admin.ModelAdmin):
# 			    #listdisplay设置要显示在列表中的字段（id字段是Django模型的默认主键）
# 			    list_display = ('id','title', 'created_time', 'modified_time', 'category', 'author')
# 			    #list_per_page设置每页显示多少条记录，默认是100条
# 			    list_per_page = 50
# 			    #ordering设置默认排序字段，负号表示降序排序
# 			    ordering = ('-id',)
# 			    #search_fields 为该列表页增加搜索栏
# 			    search_fields = ('title',)
# # 把新增的 PostAdmin 也注册进来
# admin.site.register(Post, PostAdmin)
# class CategoryAdmin(admin.ModelAdmin):
#     list_display = ('id', 'name')
# admin.site.register(Category,CategoryAdmin)
# class TagAdmin(admin.ModelAdmin):
#     list_display = ('id', 'name')
# admin.site.register(Tag,TagAdmin)

# # 更换xadmin默认主题
# from xadmin import views
# class BasdSetting(object): # 主题管理器
# 	enable_themes = True
# 	use_bootswatch = True
# xadmin.site.register(views.BaseAdminView, BasdSetting)
#
# # 修改左上角和底部logo
# class GlobalSettings(object):  # 头部系统名称和底部版权管理器
# 	site_title = '个人博客管理系统'  # 头部系统名称
# 	site_footer = 'Z16045426 李星'  # 底部版权
# 	menu_style = 'accordion'  # 设置数据管理导航折叠，以每一个app为一个折叠框
# xadmin.site.register(views.CommAdminView, GlobalSettings)  # 头部系统名称和底部版权管理器绑定views.CommAdminView注册