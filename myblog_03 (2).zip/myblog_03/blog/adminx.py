#!usr/bin/env python  
# -*- coding:utf-8 -*-
import xadmin
from .models import Post, Category, Tag,User

class UserAdmin(object):
	list_display =  ['id','name' ]# 设置数据表在后台显示的字段
	search_fields = ['id','name' ] # 设置在后台可以搜素的字段
	list_filter =   ['id','name' ] # 设置在后台可以通过条件帅选查看的字段
xadmin.site.register(User, UserAdmin) # 将制定表注册到xadmin后台

class PostAdmin(object):
	list_display =  ['id','title', 'created_time', 'modified_time', 'category', ]# 设置数据表在后台显示的字段
	search_fields = ['id','title', 'created_time', 'modified_time', 'category', ] # 设置在后台可以搜素的字段
	list_filter =   ['id','title', 'created_time', 'modified_time', 'category', ] # 设置在后台可以通过条件帅选查看的字段
xadmin.site.register(Post, PostAdmin) # 将制定表注册到xadmin后台

class CategoryAdmin(object):
	list_display =  ['id', 'name']# 设置数据表在后台显示的字段
	search_fields = ['id', 'name'] # 设置在后台可以搜素的字段
	list_filter =   ['id', 'name'] # 设置在后台可以通过条件帅选查看的字段
xadmin.site.register(Category, CategoryAdmin) # 将制定表注册到xadmin后台

class TagAdmin(object):
	list_display =  ['id', 'name']# 设置数据表在后台显示的字段
	search_fields = ['id', 'name'] # 设置在后台可以搜素的字段
	list_filter =   ['id', 'name'] # 设置在后台可以通过条件帅选查看的字段
xadmin.site.register(Tag, TagAdmin) # 将制定表注册到xadmin后台

# 更换xadmin默认主题
# from xadmin import views
from xadmin.views import BaseAdminView,CommAdminView
# 更换xadmin默认主题
class BaseSetting(object):
    enable_themes = True
    use_bootswatch = True
xadmin.site.register(BaseAdminView,BaseSetting)

# 修改左上角和底部logo
class GlobalSettings(object):  # 头部系统名称和底部版权管理器
	site_title = '个人博客管理系统'  # 头部系统名称
	site_footer = 'Z16045426 李星'  # 底部版权
	menu_style = 'accordion'  # 设置数据管理导航折叠，以每一个app为一个折叠框
xadmin.site.register(CommAdminView, GlobalSettings)  # 头部系统名称和底部版权管理器绑定views.CommAdminView注册