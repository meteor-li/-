#!usr/bin/env python  
# -*- coding:utf-8 -*-
from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^$', views.index, name='index'), # 主页
    url(r'^post/(?P<pk>[0-9]+)/$', views.detail, name='detail'), # 详情页
    url(r'^category/(?P<pk>[0-9]+)/$', views.category, name='category'), # 文章分类
    url(r'^archives/(?P<year>[0-9]{4})/(?P<month>[0-9]{1,2})/$', views.archives, name='archives'), # 文章发布时间
    url(r'^contact/$', views.contact, name='contact'), # 联系
    url(r'^search/$', views.search, name='search'), # 搜索
]