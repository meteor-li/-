from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse

class User(models.Model):
    name = models.CharField(max_length=10)

    def __str__(self):
        return self.name
    class Meta:
        verbose_name = '用户表'
        verbose_name_plural = verbose_name

class Category(models.Model):
    """
    类别
    """
    name = models.CharField(max_length=100,verbose_name='分类名')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '分类名'  # 设置表名称在django后台显示的中文名称
        verbose_name_plural = verbose_name

class Tag(models.Model):
    """
    标签
    """
    name = models.CharField(max_length=100,verbose_name='标签名')

    def __str__(self):
        return self.name
    class Meta:
        verbose_name = '标签'  # 设置表名称在django后台显示的中文名称
        verbose_name_plural = verbose_name

class Post(models.Model):
    """
    文章
    """
    views = models.PositiveIntegerField(default=0,verbose_name='阅读量')
    title = models.CharField(max_length=70,verbose_name='文章标题')
    body = models.TextField(verbose_name='文章正文')

    # 这两个列分别表示文章的创建时间和最后一次修改时间，存储时间的字段用 DateTimeField 类型。
    created_time = models.DateTimeField(verbose_name='创建时间')
    modified_time = models.DateTimeField(verbose_name='修改时间')

    excerpt = models.CharField(max_length=200, blank=True,verbose_name='文章摘要')

    category = models.ForeignKey(Category)
    tags = models.ManyToManyField(Tag, blank=True)
    user = models.ForeignKey(User)


    def __str__(self):
        return self.title
    class Meta:
        verbose_name = '文章'  # 设置表名称在django后台显示的中文名称
        verbose_name_plural = verbose_name
        ordering = ['-created_time']
    def get_absolute_url(self):
        return reverse('blog:detail', kwargs={'pk': self.pk})

    def increase_views(self):
        self.views += 1
        self.save(update_fields=['views'])


