from django.apps import AppConfig

#
# class BlogConfig(AppConfig):
#     name = 'blog'


from django.apps import AppConfig
class BlogConfig(AppConfig):
    name = 'blog'  # 当前app名称
    verbose_name = '个人博客'  # 要设置的中文名称