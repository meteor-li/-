from django.contrib import admin
from .models import Comment
import xadmin

class CommentAdmin(object):
	list_display =  ['name', 'email','url','text','created_time','post']# 设置数据表在后台显示的字段
	search_fields = ['name', 'email','url','text','created_time','post'] # 设置在后台可以搜素的字段
	list_filter =   ['name', 'email','url','text','created_time','post'] # 设置在后台可以通过条件帅选查看的字段
xadmin.site.register(Comment, CommentAdmin) # 将制定表注册到xadmin后台
